package client_to_movies_v3;

public interface Buyable {
	public int getPrice();
}
